<?php
    session_start();
    require 'db_connection.php';
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Student CRUD</title>
</head>
<body>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline"></span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="#submenu1" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Students</span> </a>
                        <ul class="collapse show nav flex-column ms-1" id="submenu1" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Add</span>Students</a>
                            </li>
                            <li>
                                <a href="insertgrade.php" class="nav-link px-0"> <span class="d-none d-sm-inline">Grade</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="process_payment.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Payment</span></a>
                    </li>
                                  <li class="w-100">
                <a href="admission.php" class="nav-link px-0"> <span class="d-none d-sm-inline">EnrollRequest</span> 1</a>
              </li>
                           
        
                    <div class="dropdown pb-4">
                        <a href="logout.php" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="d-none d-sm-inline mx-1">Logout</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
                        </ul>
                    </div>
                </ul>
            </div>
        </div>
        <div class="col py-3">
            <?php include('message.php'); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Student Details
                                <a href="create.php" class="btn btn-primary float-end">Add Students</a>
                            </h4>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Password</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $query = "SELECT * FROM account";
                                        $query_run = mysqli_query($conn, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $student)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $student['id']; ?></td>
                                                    <td><?= $student['username']; ?></td>
                                                    <td><?= $student['password']; ?></td>
                                                    <td>
                                                        <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#viewModal<?= $student['id']; ?>">View</button>
                                                        <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $student['id']; ?>">Edit</button>
                                                        <form action="code.php" method="POST" class="d-inline">
                                                            <button type="submit" name="delete_student" value="<?= $student['id']; ?>" class="btn btn-danger btn-sm">Delete</button>
                                                        </form>
                                                    </td>
                                                </tr>

                                                <!-- View Modal -->
                                                <div class="modal fade" id="viewModal<?= $student['id']; ?>" tabindex="-1" aria-labelledby="viewModalLabel<?= $student['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="viewModalLabel<?= $student['id']; ?>">Student Details</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p><strong>ID:</strong> <?= $student['id']; ?></p>
                                                                <p><strong>Username:</strong> <?= $student['username']; ?></p>
                                                                <p><strong>Password:</strong> <?= $student['password']; ?></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Edit Modal -->
                                               <!-- Edit Modal -->
<div class="modal fade" id="editModal<?= $student['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $student['id']; ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel<?= $student['id']; ?>">Edit Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">


                <form action="code.php" method="POST">
                    <input type="hidden" name="student_id" value="<?= $student['id']; ?>">
                    <div class="mb-3">
                        <label for="editUsername<?= $student['id']; ?>" class="form-label">Username</label>
                        <input type="text" class="form-control" id="editUsername<?= $student['id']; ?>" name="username" value="<?= $student['username']; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="editPassword<?= $student['id']; ?>" class="form-label">Password</label>
                        <input type="password" class="form-control" id="editPassword<?= $student['id']; ?>" name="password" value="<?= $student['password']; ?>">
                    </div>
                    <!-- Add more input fields for other student details as needed -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit"  name="update_student"class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            echo "<h5>No Record Found</h5>";
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
