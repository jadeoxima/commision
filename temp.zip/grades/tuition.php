<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true){
  header('Location: login.php');
  exit;
}

$conn = mysqli_connect("localhost", "root", "", "student_db");

if(isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    $sql = "SELECT * FROM account WHERE username='$username'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $student_id = $row['id'];
} else {
    echo "Error: Username not found in session.";
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
  $amount_paid = $_POST['amount_paid'];
  $sql = "INSERT INTO payment (student_id, amount_paid) VALUES ('$student_id', '$amount_paid')";
  mysqli_query($conn, $sql);
}

$sql = "SELECT * FROM tuition WHERE student_id='$student_id'";
$result = mysqli_query($conn, $sql);
$total_amount_due = 0;

while($row = mysqli_fetch_assoc($result)) {
  $total_amount_due += $row['amount'];
}

$sql = "SELECT SUM(amount_paid) as total_amount_paid FROM payment WHERE student_id='$student_id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_amount_paid = $row['total_amount_paid'];

$total_balance = $total_amount_due - $total_amount_paid;
?>

<!DOCTYPE html>
<html>
<head>
  <title>Tuition</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="sidebar">
  <br>
  <br>
  <br>
  <br>

  <a class="active" href="#home">Home</a>
  <a href="#news">My Account</a>
  <a href="tuition.php">Balance</a>
  <a href="#about">Setting</a>
  <a href="logout.php">Logout</a>

</div>
<div class="content">
<br>
<br>
<br>

<table class="table">
  <thead>
    <tr>
      <th>Student Name</th>
      <th>Balance</th>
      <th>Total Amount Due</th>
      <th>Total Amount Paid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><?php echo $username; ?></td>
      <td><?php echo $total_balance; ?></td>
      <td><?php echo $total_amount_due; ?></td>
      <td><?php echo $total_amount_paid; ?></td>
    </tr>
  </tbody>
</table>

<h2>Payment History</h2>

<table class="table">
  <thead>
    <tr>
      <th>Name</th>
      <th>Date</th>
      <th>Amount Paid</th>
    </tr>
  </thead>
  <tbody>
    <?php
      $sql = "SELECT * FROM payment, account WHERE username='$username'";
      $result = mysqli_query($conn, $sql);

      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['payment_date'] . "</td>";
        echo "<td>" . $row['amount_paid'] . "</td>";
        echo "</tr>";
      }
    ?>
  </tbody>
</table>

</body>
</html>
