<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $conn = mysqli_connect("localhost", "root", "", "student_db");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if the user is an admin
        $query = "SELECT * FROM account WHERE username=? AND password=? AND is_admin=1";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $_SESSION['username'] = $username;
            $_SESSION['loggedin'] = true;
            $_SESSION['is_admin'] = true;
            header('Location: mainadmin.php');
        } else {
            // Check if the user is a regular user
            $query = "SELECT * FROM account WHERE username=? AND password=? AND is_admin=0";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $_SESSION['username'] = $username;
                $_SESSION['loggedin'] = true;
                header('Location: dashboard.php');
            } else {
                echo "Invalid username or password.";
            }
        }

        $conn->close();
    } else {
        echo "Please enter a username and password.";
    }
}
?>
