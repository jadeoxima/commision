<?php
// connect to database
$conn = mysqli_connect("localhost", "root", "", "student_db");

// check for database connection errors
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (!isset($_GET['student_id'])) {
    die("Student ID is required");
}
$student_id = $_GET['student_id'];

$sql = "SELECT SUM(amount) as total_tuition FROM tuition WHERE student_id=$student_id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_tuition = $row['total_tuition'];


$sql = "SELECT SUM(amount_paid) as total_payments FROM payment WHERE student_id=$student_id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_payments = $row['total_payments'];

$balance = $total_tuition - $total_payments;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Tuition Balance</title>
</head>
<body>
    <h1>Student Tuition Balance</h1>
    <p><strong>Student ID:</strong> <?php echo $student_id; ?></p>
    <p><strong>Tuition Balance:</strong> <?php echo $balance; ?></p>
</body>
</html>
