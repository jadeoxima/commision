<?php
session_start();
require 'new.php';


 ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <div class="container">
            <a href="index.PHP" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
                <h2 class="m-0 text-primary"><i class="fa fa-book me-3"></i>Enrollment</h2>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ms-auto p-4 p-lg-0">
                    <li class="nav-item">
                        <a href="index.PHP" class="nav-link">Home</a>
                    </li>
                    <li class="nav-item">
                        <a href="enrolle.php" class="nav-link">Enrollment</a>
                    </li>
                    <li class="nav-item">
                        <a href="login.html" class="nav-link">Login</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    < <section id="agreement">
        <div class="container">
            <div class="guide-wrapper">
                <div class="guide-content">
                    <h1>Agreements</h1>
                    <p>By filling out this form, you are agreeing to the Data Policy of the SJPEF </p>
                    <div class="requirements">
                        <ul>
                            <li>We collect and store your data.</li>
                            <li>We review and do not share to any institutions.</li>
                            <li>Personal Information such as names and other must be valid and true.</li>
                            <li>Once you submitted the form, you cannot undo it.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="guide">
        <div class="container">
            <div class="guide-wrapper">
                <div class="guide-content">
                    <h1>Requirements</h1>
                    <p>Requirements for Enrollment</p>
                    <p>After filling out the form, please bring the following:</p>
                    <div class="requirements">
                        <ul>
                            <li>2x2 Picture, White Background</li>
                            <li>Report Card</li>
                            <li>Good Moral</li>
                            <li>Form 137</li>
                            <li>Birth Certificate</li>
                            <li>Complete the filling out of the Enrollment Form.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section id="firstform">
    <div class="container">
        <div class="firstform-wrapper">
            <form action="request.php" method="post">

                <div class="left">
                    <h1>PERSONAL INFORMATION</h1>
                    <p>Complete the form and submit. After submission, you will receive your username and password.<br>
                        After your first login, complete the remaining information and wait for the process result.
                    </p>
                    <div class="mb-3">
                                <label>Name</label>
                                <input type="text" name="fname" class="form-control">
                            </div>
                               <div class="mb-3">
                                
                            <div class="mb-3">
                                <label>Middle Name</label>
                                <input type="text" name="mname" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label>Last Name</label>
                                <input type="text" name="lnmae" class="form-control">
                            </div>
                              <div class="mb-3">
                                <label>Age</label>
                                <input type="text-primary" name="Age" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label>Student Email</label>
                                <input type="email" name="email" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label>ADDRESS</label>
                                <input type="text" name="Address" class="form-control">
                            </div>

                               <div class="mb-3">
                                <label>Gender</label>
                                <input type="text" name="Gender" class="form-control">
                            </div>
                             <div class="mb-3">
                                <label>Guardian</label>
                                <input type="text" name="Guardian" class="form-control">
                            </div>

                                    <div class="mb-3">
                                <label>GContact</label>
                                <input type="text" name="GContact" class="form-control">
                            </div>
                             



              <div class="form-group">
  <label for="services">Course Want to Enroll</label>
  <select class="form-control" id="services" name="CWE" required>
    <option>BSIT</option>
    <option>BSA</option>
    <option>CAS</option>
    <option>CHMT</option>
  </select>
</div>
<br>
                            <div class="mb-3">
                                <button type="submit" name="save_student" class="btn btn-primary">Save Student</button>
                            </div>
                    </div>
    
            </form>
        </div>
    </div>

            </div>
        </div>
    </section>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.7.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Template Script -->
    <script src="js/script.js"></script>

</body>

</html>
