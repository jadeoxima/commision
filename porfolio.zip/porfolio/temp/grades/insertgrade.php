<?php
$conn = mysqli_connect("localhost", "root", "", "student_db");

if(isset($_POST['student_id'], $_POST['subject'], $_POST['grade'], $_POST['semester'])) {
    $student_id = intval($_POST['student_id']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $grade = floatval($_POST['grade']);
    $year_level = mysqli_real_escape_string($conn, $_POST['year_level']);

    $stmt = mysqli_prepare($conn, "INSERT INTO grade (student_id, subject, grade,   year_level) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "isds", $student_id, $subject, $grade, $year_level);
    mysqli_stmt_execute($stmt);

    header("Location: insertgrade.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Insert Grade</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<?php
session_start();
require 'db_connection.php';
?>
<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <title>Student CRUD</title>
</head>
<body>
<div class="container-fluid">
  <div class="row flex-nowrap">
    <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
      <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
        <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
          <span class="fs-5 d-none d-sm-inline"></span>
        </a>
        <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
          <li class="nav-item">
            <a href="mainadmin.php" class="nav-link align-middle px-0">
              <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
            </a>
          </li>
          <li>
            <a href="#submenu1" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
              <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Students</span> </a>
            <ul class="collapse show nav flex-column ms-1" id="submenu1" data-bs-parent="#menu">
              <li>
                <a href="insertgrade.php" class="nav-link px-0"> <span class="d-none d-sm-inline">Grade</a>
              </li>
            </ul>
          </li>
          <li>
            <a href="prcocess_payment.php" class="nav-link px-0 align-middle">
              <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Payment</span></a>
          </li>
          <li>
            
              <li class="w-100">
                <a href="admission.php" class="nav-link px-0"> <span class="d-none d-sm-inline">EnrollRequest</span> 1</a>
              </li>
              <li>
                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span> 2</a>
              </li>
            </ul>
          </li>
          <div class="dropdown pb-4">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
              <span class="d-none d-sm-inline mx-1">Logout</span>
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
              <li>
                <hr class="dropdown-divider">
              </li>
              <li><a class="dropdown-item" href="#">Sign out</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div class="container">
        <h1>Insert Grade</h1>
        <form method="post" action="insertgrade.php">
          <div class="form-group">
            <label for="student_id">Student ID:</label>
            <input type="text" class="form-control" id="student_id" name="student_id">
          </div>
          <div class="form-group">
            <label for="subject">Subject:</label>
            <input type="text" class="form-control" id="subject" name="subject">
          </div>
          <div class="form-group">
            <label for="grade">Grade:</label>
            <input type="text" class="form-control" id="grade" name="grade">
          </div>
          <div class="form-group">
            <label for="semester">Semester:</label>
            <input type="text" class="form-control" id="year_level" name="year_level">
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
