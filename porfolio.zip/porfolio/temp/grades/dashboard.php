<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="styles.css">

</head>
<body>

<div class="container-fluid">
  <?php
  session_start();

  if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
      exit('Error: Please log in');
  }

  $conn = mysqli_connect("localhost", "root", "", "student_db");

  if (isset($_SESSION['username'])) {
      $username = $_SESSION['username'];
      $sql = "SELECT subject, grade FROM grade INNER JOIN account ON grade.student_id = account.id WHERE username=?";
      $stmt = mysqli_prepare($conn, $sql);
      mysqli_stmt_bind_param($stmt, "s", $username);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);

      $sql = "SELECT AVG(grade) as average FROM grade INNER JOIN account ON grade.student_id = account.id WHERE username=?";
      $stmt = mysqli_prepare($conn, $sql);
      mysqli_stmt_bind_param($stmt, "s", $username);
      mysqli_stmt_execute($stmt);
      $row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
      $general_average = $row['average'];

      $sql = "SELECT SUM(amount) as total_paid FROM tuition INNER JOIN account ON tuition.student_id = account.id WHERE username=?";
      $stmt = mysqli_prepare($conn, $sql);
      mysqli_stmt_bind_param($stmt, "s", $username);
      mysqli_stmt_execute($stmt);
      $tuition_row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
      $tuition_paid = $tuition_row['total_paid'];
      $tuition_balance = 10000 - $tuition_paid;
  } else {
      echo "Error: Username not found in session.";
  }
  ?>

  <h1>My Account, <?php echo isset($username) ? $username : ''; ?></h1>
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#grades">Grades</a></li>
    <li><a data-toggle="tab" href="#payment">Payment</a></li>
    <li><a data-toggle="tab" href="#semester">Semester</a></li>
  </ul>

  <div class="tab-content">
    <div id="grades" class="tab-pane fade in active">
      <h2>Grades</h2>
      <table class="table">
        <thead>
          <tr>
            <th>Subject</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if (mysqli_num_rows($result) > 0) {
            mysqli_data_seek($result, 0);
            while ($row = mysqli_fetch_assoc($result)) {
              ?>
              <tr>
                <td><?php echo $row['subject']; ?></td>
                <td><?php echo $row['grade']; ?></td>
              </tr>
              <?php
            }
          } else {
            ?>
            <tr>
              <td colspan="2">No grades found for this student</td>
            </tr>
            <?php
          }
          ?>
          <tr>
            <td><strong>General Average:</strong></td>
            <td><?php echo $general_average; ?></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div id="payment" class="tab-pane fade">
      <h2>Payment</h2>
      <p>Tuition Paid: $<?php echo $tuition_paid; ?></p>
      <p>Tuition Balance: $<?php echo $tuition_balance; ?></p>
    </div>
    <div id="semester" class="tab-pane fade">
      <h2>Semester</h2>
      <!-- Add your semester content here -->
    </div>
  </div>

  <form action="logout.php" method="post">
    <button type="submit" class="btn btn-primary">Sign Out</button>
  </form>

</div>
</body>
</html>
