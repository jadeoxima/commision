<?php
    session_start();
    require 'new.php';
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Student CRUD</title>
</head>
<body>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline"></span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="#" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="#submenu1" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-speedometer2"></i> <span class="ms-1 d-none d-sm-inline">Students</span> </a>
                        <ul class="collapse show nav flex-column ms-1" id="submenu1" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Add Students</span></a>
                            </li>
                            <li>
                                <a href="insertgrade.php" class="nav-link px-0"> <span class="d-none d-sm-inline">Grade</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Payment</span></a>
                    </li>
                    <li>
                        <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                            <i class="fs-4 bi-bootstrap"></i> <span class="ms-1 d-none d-sm-inline">Admission</span></a>
                        <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="admimsion.php" class="nav-link px-0"> <span class="d-none d-sm-inline">New Enroll/Transferee</span></a>
                            </li>
                            <li>
                                <a href="#" class="nav-link px-0"> <span class="d-none d-sm-inline">Item</span></a>
                            </li>
                        </ul>
                    </li>
          
                    <div class="dropdown pb-4">
                        <a href="logout.php" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="d-none d-sm-inline mx-1">Logout</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
                        </ul>
                    </div>
                </ul>
            </div>
        </div>
        <div class="col py-3">
            <?php include('message.php'); ?>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Student  Request
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Middle Name</th>
                                        <th>Last Name</th>
                                        <th>Age</th>
                                        <th>Student Email</th>
                                        <th>ADDRESS</th>
                                        <th>Gender</th>
                                        <th>Guardian</th>
                                        <th>GContact</th>
                                        <th>Course Want to Enroll</th>
                                        <
                                        <!-- Add new info column headers as needed -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $query = "SELECT * FROM enrollee";
                                        $query_run = mysqli_query($con, $query);

                                        if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $student)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $student['id']; ?></td>
                                                    <td><?= $student['fname']; ?></td>
                                                    <td><?= $student['mname']; ?></td>
                                                    <td><?= $student['lnmae']; ?></td>
                                                    <td><?= $student['Age']; ?></td>
                                                    <td><?= $student['email']; ?></td>
                                                    <td><?= $student['Gender']; ?></td>
                                                    <td><?= $student['Guardian']; ?></td>
                                                    <td><?= $student['GContact']; ?></td>
                                                    <td><?= $student['CWE']; ?></td>
                                                    <td><?= $student['status']; ?></td>

                                                    <td>
                                                        <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#viewModal<?= $student['id']; ?>">View</button>
                                                        <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $student['id']; ?>">Edit</button>
                                                        <form action="request.php" method="POST" class="d-inline">
                                                            <button type="submit" name="delete_student" value="<?= $student['id']; ?>" class="btn btn-danger btn-sm">Delete</button>
                                                        </form>
                                                    </td>
                                                </tr>

                                                <!-- View Modal -->
                                                <div class="modal fade" id="viewModal<?= $student['id']; ?>" tabindex="-1" aria-labelledby="viewModalLabel<?= $student['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="viewModalLabel<?= $student['id']; ?>">Student Details</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p><strong>ID:</strong> <?= $student['id']; ?></p>
                                                                <p><strong>First Name:</strong> <?= $student['fname']; ?></p>
                                                                <p><strong>Middle Name:</strong> <?= $student['mname']; ?></p>
                                                                <p><strong>Last Name:</strong> <?= $student['lnmae']; ?></p>
                                                                <p><strong>Age:</strong> <?= $student['Age']; ?></p>
                                                                <p><strong>Email:</strong> <?= $student['email']; ?></p>
                                                                <p><strong>Gender:</strong> <?= $student['Gender']; ?></p>
                                                                <p><strong>Guardian:</strong> <?= $student['Guardian']; ?></p>
                                                                <p><strong>Guardian Contact:</strong> <?= $student['GContact']; ?></p>
                                                                <p><strong>CWE:</strong> <?= $student['CWE']; ?></p>
                                                                <p><strong>Status:</strong> <?= $student['status']; ?></p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Edit Modal -->
                                                <div class="modal fade" id="editModal<?= $student['id']; ?>" tabindex="-1" aria-labelledby="editModalLabel<?= $student['id']; ?>" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="editModalLabel<?= $student['id']; ?>">Edit Student Details</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form action="request.php" method="POST">
                                                                    <input type="hidden" name="id" value="<?= $student['id']; ?>">
                                                                    <div class="mb-3">
                                                                        <label for="edit_fname" class="form-label">First Name</label>
                                                                        <input type="text" name="fname" class="form-control" id="fname" value="<?= $student['fname']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_mname" class="form-label">Middle Name</label>
                                                                        <input type="text" name="mname" class="form-control" id="mname" value="<?= $student['mname']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_lname" class="form-label">Last Name</label>
                                                                        <input type="text" name="lnmae" class="form-control" id="edit_lname" value="<?= $student['lnmae']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_age" class="form-label">Age</label>
                                                                        <input type="number" name="Age" class="form-control" id="edit_age" value="<?= $student['Age']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_email" class="form-label">Email</label>
                                                                        <input type="email" name="email" class="form-control" id="email" value="<?= $student['email']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_gender" class="form-label">Gender</label>
                                                                        <select class="form-select" name="Gender" id="Gender">
                                                                            <option value="Male" <?php if($student['Gender'] == 'Male') echo 'selected'; ?>>Male</option>
                                                                            <option value="Female" <?php if($student['Gender'] == 'Female') echo 'selected'; ?>>Female</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_guardian" class="form-label">Guardian</label>
                                                                        <input type="text" name="Guardian" class="form-control" id="Guardian" value="<?= $student['Guardian']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_gcontact" class="form-label">Guardian Contact</label>
                                                                        <input type="text" name="GContact" class="form-control" id="GContact" value="<?= $student['GContact']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                                        <label for="edit_cwe" class="form-label">CWE</label>
                                                                        <input type="text" name="CWE" class="form-control" id="CWE" value="<?= $student['CWE']; ?>">
                                                                    </div>
                                                                    <div class="mb-3">
                                                        <label for="edit_status" class="form-label">Status</label>
                                                        <select name="status" class="form-select" id="edit_status">
                                                        <option value="Accept" <?= ($student['status'] == 'Accept') ? 'selected' : ''; ?>>Accept</option>
                                                         <option value="Decline" <?= ($student['status'] == 'Decline') ? 'selected' : ''; ?>>Decline</option>
                                                         <option value="Pending" <?= ($student['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                                                          </select>
                                                            </div>

 <button type="submit"  name="update_student"class="btn btn-primary">Save Changes</button>                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            echo "No record found.";
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Optional JavaScript; choose one of the two! -->
<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Option 2: Separate Popper and Bootstrap JS -->
<!-- <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script> -->
</body>
</html>