<?php
session_start();
require 'db_connection.php';

if (isset($_POST['delete_student'])) {
    $student_id = $_POST['delete_student'];

    // Use prepared statements to prevent SQL injection
    $query = "DELETE FROM account WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $_SESSION['message'] = "Student Deleted Successfully";
        $_SESSION['deleted'] = true;
    } else {
        $_SESSION['message'] = "Student Not Deleted";
    }

    // Redirect back to mainadmin.php
    header("Location: mainadmin.php");
    exit(0);
}

if(isset($_POST['update_student']))
{
    $student_id = mysqli_real_escape_string($conn, $_POST['student_id']);

    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    

    $query = "UPDATE account SET username='$username', password='$password' WHERE id='$student_id' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
{
    $_SESSION['message'] = "Student Deleted Successfully";
    header("Location: mainadmin.php");
    exit(0);
}
    else
    {
        $_SESSION['message'] = "Student Not Updated";
        header("Location: mainadmin.php");
        exit(0);
    }

}


if(isset($_POST['save_student']))
{
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lnmae = mysqli_real_escape_string($conn, $_POST['lnmae']);
        $emal = mysqli_real_escape_string($conn, $_POST['lnmae']);



    $query = "INSERT INTO enrollee (fname,lnmae) VALUES ('$fname','$lnmae')";

    $query_run = mysqli_query($conn, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Student Created Successfully";
        header("Location: create.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: create.php");
        exit(0);
    }
}




?>