<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['username']) && !empty($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $conn = mysqli_connect("localhost", "root", "", "student_db");

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $query = "SELECT * FROM account WHERE username='$username' AND password='$password'";
        $result = $conn->query($query);

        if ($result->num_rows == 1) {
            $_SESSION['username'] = $username;
            $_SESSION['loggedin'] = true; // add loggedin session variable
            header('Location: mainadmin.php');
        } else {
            echo "Invalid username or password.";
        }

        $conn->close();
    } else {
        echo "Please enter a username and password.";
    }
}
