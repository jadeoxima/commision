<?php
session_start();


$conn = mysqli_connect("localhost", "root", "", "student_db");

if(isset($_POST['student_id']) && isset($_POST['amount'])) {
    $student_id = $_POST['student_id'];
    $amount = $_POST['amount'];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE id='$student_id'");
    if(mysqli_num_rows($result) == 0) {
        echo "Error: Student not found in database.";
        exit;
    }

    $insert_query = "INSERT INTO tuition (student_id, amount) VALUES ('$student_id', '$amount')";
    if(mysqli_query($conn, $insert_query)) {
        echo "Payment processed successfully!";
    } else {
        echo "Error processing payment: " . mysqli_error($conn);
    }
} 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>eLEARNING - eLearning HTML Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<div class="container-fluid">
    <div class="row flex-nowrap">
        <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
            <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                <a href="/" class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                    <span class="fs-5 d-none d-sm-inline"></span>
                </a>
                <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start" id="menu">
                    <li class="nav-item">
                        <a href="mainadmin.php" class="nav-link align-middle px-0">
                            <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                        </a>
                    </li>
                    <li>
                        
                        <ul class="collapse show nav flex-column ms-1" id="submenu1" data-bs-parent="#menu">
                                <a href="insertgrade.php" class="nav-link px-0"> <span class="d-none d-sm-inline">Grade</span></a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="process_payment.php" class="nav-link px-0 align-middle">
                            <i class="fs-4 bi-table"></i> <span class="ms-1 d-none d-sm-inline">Payment</span></a>
                    </li>
                    <li>
                        <a href="#submenu2" data-bs-toggle="collapse" class="nav-link px-0 align-middle ">
                            <i class="fs-4 bi-bootstrap"></i> <span class="ms-1 d-none d-sm-inline">Admission</span></a>
                        <ul class="collapse nav flex-column ms-1" id="submenu2" data-bs-parent="#menu">
                            <li class="w-100">
                                <a href="admimsion.php" class="nav-link px-0"> <span class="d-none d-sm-inline">New Enroll/Transferee</span></a>
                            </li>
                            
                        </ul>
                    </li>
          
                    <div class="dropdown pb-4">
                        <a href="logout.php" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <span class="d-none d-sm-inline mx-1">Logout</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="logout.php">Sign out</a></li>
                        </ul>
                    </div>
                </ul>
            </div>
        </div>

<div class="container">
  <h2>Tuition Payment</h2>
  <form method="post" action="process_payment.php">
    <div class="form-group">
      <label for="student_id">Student ID:</label>
      <input type="text" class="form-control" id="student_id" name="student_id">
    </div>
    <div class="form-group">
      <label for="amount">Amount:</label>
      <input type="text" class="form-control" id="amount" name="amount">
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>