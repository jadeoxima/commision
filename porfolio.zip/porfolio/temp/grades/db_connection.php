<?php
$host = 'localhost'; // the host where your database resides
$user = 'root'; // the username used to connect to the database
$password = ''; // the password for the user
$database = 'student_db'; // the name of the database

// create a database connection
$conn = mysqli_connect("localhost", "root", "", "student_db");

// check for connection errors
if ($conn->connect_error) {
  die('Database connection failed: ' . $conn->connect_error);
}

                                
?>
