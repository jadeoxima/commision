<?php
session_start();
require 'new.php';



if(isset($_POST['delete_student']))
{
    $student_id = mysqli_real_escape_string($con, $_POST['delete_student']);

    $query = "DELETE FROM enrollee WHERE id='$student_id' ";
    $query_run = mysqli_query($con, $query);

    if($query_run)
    {
        $_SESSION['message'] = "Student Deleted Successfully";
        header("Location: admimsion.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Deleted";
        header("Location: admimsion.php");
        exit(0);
    }
}


if (isset($_POST['update_student'])) {
    $id = $_POST['id'];
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $mname = mysqli_real_escape_string($con, $_POST['mname']);
    $lnmae = mysqli_real_escape_string($con, $_POST['lnmae']);
    $Age = mysqli_real_escape_string($con, $_POST['Age']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $Gender = mysqli_real_escape_string($con, $_POST['Gender']);
    $Guardian = mysqli_real_escape_string($con, $_POST['Guardian']);
    $GContact = mysqli_real_escape_string($con, $_POST['GContact']);
    $CWE = mysqli_real_escape_string($con, $_POST['CWE']);
    $status = mysqli_real_escape_string($con, $_POST['status']);

    $query = "UPDATE enrollee SET fname='$fname', mname='$mname', lnmae='$lnmae', Age='$Age', email='$email', Gender='$Gender', Guardian='$Guardian', GContact='$GContact', CWE='$CWE', status='$status' WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        $_SESSION['success'] = "Student details updated successfully";
    } else {
        $_SESSION['error'] = "Failed to update student details";
    }

    header('Location: admimsion.php');
}


if(isset($_POST['save_student']))
{
    $fname = mysqli_real_escape_string($con, $_POST['fname']);
    $mname = mysqli_real_escape_string($con, $_POST['mname']);
    $lnmae = mysqli_real_escape_string($con, $_POST['lnmae']);
    $Age = mysqli_real_escape_string($con, $_POST['Age']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
     $Address = mysqli_real_escape_string($con, $_POST['Address']);
     $Gender = mysqli_real_escape_string($con, $_POST['Gender']);
     $Guardian = mysqli_real_escape_string($con, $_POST['Guardian']);
     $GContact = mysqli_real_escape_string($con, $_POST['GContact']);
    $CWE = mysqli_real_escape_string($con, $_POST['CWE']);



    $query = "INSERT INTO enrollee (fname,mname,lnmae,Age,email,Address,Gender,Guardian,GContact,CWE) VALUES ('$fname','$mname','$lnmae','$Age','$email',' $Address',' $Gender','$Guardian', $GContact','$CWE')";
    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Student Created Successfully";
        header("Location: enrolle.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Student Not Created";
        header("Location: enrolle.php");
        exit(0);
    }
}

?>